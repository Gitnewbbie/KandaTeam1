package bean;

public class Admin {
	private String adminId;
	private String adminName;
	private String password;
	private String email;

	public Admin() {
		adminId = null;
		adminName = null;
		password = null;
		email = null;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getAdminId() {
		return adminId;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

}
