package servlet.admin;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.*;
import dao.InquiryDAO;

public class SearchServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";   // エラー文を格納する変数
		ArrayList<Inquiry> inquiryList = new ArrayList<Inquiry>();
		String item = "";
		String userName = "";

		try {

			// セッションの取得
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの場合
			if (admin == null) {
				error = "セッション切れの為、一覧表示は行なえませんでした。";
				return;
			}

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// inquiryDAOをオブジェクト化
			InquiryDAO inqdao = new InquiryDAO();

			// パラメータの取得
			userName = request.getParameter("name");				// 名前を格納する変数
			item = request.getParameter("item");						// 項目を格納する変数

			// 検索結果を格納するList
			if(item.equals("")) {
				inquiryList = inqdao.search(userName);
			} else {
				inquiryList = inqdao.search(userName, item);
			}

			// 検索結果を持ってinq_infoにフォワード
			request.setAttribute("inquiry_list", inquiryList);

		// データベース接続時のエラーを出力する
		} catch (IllegalStateException e) {

			error = "DB接続エラー";

		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。<br>" + e;

		} finally {

			if (error.equals("")) {

				/*
				 *  6/10追加
				 *  検索した際に用いた item name をリクエストスコープでlist.jspに受け渡し
				 */
				request.setAttribute("item", item);
				request.setAttribute("name", userName);
				request.getRequestDispatcher("/view/admin/list.jsp").forward(request, response);
			} else {

				request.setAttribute("error", error);
				request.setAttribute("cmd", "admin");
				request.getRequestDispatcher("/view/common/error.jsp").forward(request, response);
			}
		}
	}

	public void doPost(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		this.doGet(request, response);
	}
}
