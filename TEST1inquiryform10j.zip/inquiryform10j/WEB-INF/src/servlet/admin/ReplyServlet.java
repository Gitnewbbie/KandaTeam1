/*
 * プログラム名：お問い合わせシステムVer1.0 ReplyServlet.java
 * プログラムの説明：お問い合わせ返信処理を行うサーブレット
 * 作成者：宮田　慧士
 * 作成日：2021年6月9日
 */

package servlet.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.*;
import dao.InquiryDAO;
import util.SendMail;

public class ReplyServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// ダイレクトアクセスがあった場合は一覧画面に遷移
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		String error = ""; // エラーメッセージ
		String cmd = "";   // 遷移先分岐用コマンド変数

		try {

			// セッションの取得
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの場合
			if (admin == null) {
				error = "セッション切れの為、一覧表示は行なえませんでした。";
				return;
			}

			InquiryDAO inquiryDao = new InquiryDAO(); // DAOオブジェクト
			SendMail sendMail = new SendMail();       // メール送信ライブラリ

			// パラメータの取得
			request.setCharacterEncoding("UTF-8");
			String subject = request.getParameter("subject");      // メールの件名
			String text = request.getParameter("text");            // メールの内容
			String inquiryId = request.getParameter("inquiry_id"); // 問い合わせID取得

			// お問い合わせ情報の取得
			Inquiry inquiry = inquiryDao.selectById(inquiryId);

			// リクエストスコープに登録
			request.setAttribute("inquiry", inquiry);
			request.setAttribute("subject", subject);
			request.setAttribute("text", text);

		} catch (IllegalStateException e) {

			// DB接続エラー
			error = "DB接続エラーの為、お問い合わせ返信は行えません。";
		} catch (Exception e) {

			// 予期せぬエラー
			error = "予期せぬエラーが発生した為、お問い合わせ返信は行なえませんでした。";
		} finally {

			if (error.equals("")) {

				// エラーが発生していない場合、返信確認画面へ遷移
				request.getRequestDispatcher("/view/admin/confirmAdmin.jsp").forward(request, response);

			} else {

				// エラーが発生した場合、エラー画面へ遷移
				request.setAttribute("error", error);
				request.setAttribute("cmd", "admin");
				request.getRequestDispatcher("/view/common/error.jsp").forward(request, response);
			}
		}
	}
}
