●サイト訪問者側の入り口
　　\otoiawase\WebContent\view\user\home.html

●管理者側の入り口
　　\otoiawase\WebContent\view\admin\login.html