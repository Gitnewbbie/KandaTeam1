package servlet.admin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.*;
import dao.InquiryDAO;
import util.SendMail;


public class CheckAdminServlet extends HttpServlet{

	public void doPost(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		this.doGet(request, response);
	}

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";   // エラー文を格納する変数

		try {

			// セッションの取得
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの場合
			if (admin == null) {
				error = "セッション切れの為、一覧表示は行なえませんでした。";
				return;
			}

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// オブジェクト生成
			SendMail send_mail = new SendMail();
			InquiryDAO inquiryDao = new InquiryDAO();

			// パラメータの取得
			String inquiryId = request.getParameter("inquiry_id"); // 問い合わせID
			String subject = request.getParameter("subject");      // 件名を格納する変数
			String text = request.getParameter("text");            // 内容を格納する変数

			// 問い合わせ情報取得
			Inquiry inquiry = inquiryDao.selectById(inquiryId);
			// 送信メール情報設定
			String path = getServletContext().getRealPath("templete\\inquiry_reply.txt");
			File file = new File(path);
			if (!file.exists()) {
				error = "メールが送信できませんでした。";
				return;
			}
			byte[] bytes = Files.readAllBytes(Paths.get(path));
			String bodytext = new String(bytes, StandardCharsets.UTF_8); // メール送信情報設定
			bodytext = bodytext.replace("%text%", text);

			// 送信できたかの判定
			send_mail.setFromInfo("test.sender@kanda-it-school-system.com", "書籍管理システム");
			//送信先のメールアドレスの指定
			send_mail.setRecipients(inquiry.getUserEmail());
			//メールの件名の指定
			send_mail.setSubject(subject);
			//メールの本文の指定
			send_mail.setText(bodytext);
			boolean judge = send_mail.forwardMail();

			// メール送信のエラーはいったん無視
			if(!judge) {
				error = "送信できませんでした。";
				return;
			}

			// メール送信状態の変更
			inquiryDao.update(inquiryId, admin.getAdminId(), text);


		// データベース接続時のエラーを出力する
		} catch (IllegalStateException e) {

			error = "DB接続エラー";
			return;

		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。<br>" + e;

		} finally {

			if (error.equals("")) {
				request.getRequestDispatcher("/view/admin/completeAdmin.jsp").forward(request, response);
			} else {

				request.setAttribute("error", error);
				request.setAttribute("cmd", "admin");
				request.getRequestDispatcher("/view/common/error.jsp").forward(request, response);
			}
		}

	}

}
