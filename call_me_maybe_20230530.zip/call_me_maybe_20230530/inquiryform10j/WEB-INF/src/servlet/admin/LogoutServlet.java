package servlet.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

public class LogoutServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		try {
			HttpSession session = request.getSession();
			session.invalidate();

		} catch (Exception e) {

		} finally {
			request.getRequestDispatcher("/view/admin/login.jsp").forward(request, response);
		}

	}
}
