package servlet.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.Inquiry;
import dao.InquiryDAO;

public class InsertServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		InquiryDAO inquiryDao = new InquiryDAO(); // 処理オブジェクトの作成
		Inquiry inquiry = new Inquiry(); // お問い合わせオブジェクトの作成

		request.setCharacterEncoding("UTF-8"); // 文字エンコーディングの指定

		// 各パラメータの取得
		String userName = request.getParameter("user_name"); // お名前
		String userEmail = request.getParameter("user_email"); // メールアドレス
		String age = request.getParameter("age"); // 年齢
		String gender = request.getParameter("gender"); // 性別
		String address = request.getParameter("address"); // 住所
		String item = request.getParameter("item"); // 項目
		String content = request.getParameter("content"); // お問い合わせ内容

		String error = ""; // エラーメッセージの初期値
		String emailError = "";

		try {

			// 登録に必要な各パラメータの格納
			inquiry.setUserName(userName);
			inquiry.setUserEmail(userEmail);
			inquiry.setAge(age);
			inquiry.setGender(gender);
			inquiry.setAddress(address);
			inquiry.setItem(item);
			inquiry.setContent(content);

		} catch (Exception e) {

			error = "予期せぬエラーが発生しました。";


		} finally {
			if (error.equals("")) { // エラーが無い場合

				if (emailError.equals("")) {

					request.setAttribute("Inquiry", inquiry); // お問い合わせデータをリクエストスコープに格納
					request.getRequestDispatcher("/view/user/confirm.jsp").forward(request, response); // フォワード処理
				} else {

					// エラーメッセージをもってお問い合わせ画面にフォワード
					request.setAttribute("email_error", emailError);
					request.getRequestDispatcher("/view/user/inquiry.jsp").forward(request, response); // フォワード処理
				}


			} else { // エラーが有る場合

				request.setAttribute("error", error);
				request.setAttribute("cmd", "user");
				request.getRequestDispatcher("/view/user/error.jsp").forward(request, response); // フォワード処理
			}

		}

	}

}
