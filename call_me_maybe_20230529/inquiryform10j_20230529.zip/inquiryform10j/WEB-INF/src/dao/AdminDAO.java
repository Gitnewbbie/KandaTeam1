package dao;

import java.sql.*;

import bean.Admin;

public class AdminDAO {
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/inquirydb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// DBに接続
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*
	 * 検索機能 渡されたユーザー名とパスワードが一致する場合詳細情報を返す
	 */
	public Admin selectByUser(String name, String password) {

		Connection con = null;
		Statement smt = null;

		Admin admin = new Admin();

		try {
			// DBに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文
			String sql = "SELECT * FROM admin_info WHERE admin_name = '" + name + "' AND password = '" + password + "'";

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 情報を取得
			while (rs.next()) {
				admin.setAdminId(rs.getString("admin_id"));
				admin.setAdminName(rs.getString("admin_name"));
				admin.setPassword(rs.getString("password"));
				admin.setEmail(rs.getString("admin_email"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return admin;
	}

	/*
	 * idと合致する管理者の名前を取得する
	 *
	 * 詳細画面の変更(メソッド全体)
	 */

	public String selectByadminname(int id) {

		Connection con = null;
		Statement smt = null;

		String admin_name = "";

		try {
			// DBに接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文
			String sql = "SELECT * FROM admin_info WHERE admin_id = '" + id + "'";

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 情報を取得
			while (rs.next()) {
				admin_name = rs.getString("admin_name");
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return admin_name;
	}
}
