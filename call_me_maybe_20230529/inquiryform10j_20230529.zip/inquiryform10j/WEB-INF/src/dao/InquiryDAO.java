package dao;

import java.sql.*;
import java.util.ArrayList;

import bean.Inquiry;

public class InquiryDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/inquirydb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// お問い合わせ全件取得（日時降順）
	public ArrayList<Inquiry> selectAll() {

		Connection con = null;
		Statement smt = null;

		ArrayList<Inquiry> list = new ArrayList<Inquiry>();

		try {

			String sql = "SELECT * FROM inquiry_info ORDER BY inquiry_date desc;";

			con = InquiryDAO.getConnection();
			smt = con.createStatement();
			System.out.println(sql);
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Inquiry inquiry = new Inquiry();
				inquiry.setInquiryId(rs.getString("inquiry_id"));
				inquiry.setUserName(rs.getString("user_name"));
				inquiry.setItem(rs.getString("item"));
				inquiry.setInquiryDate(rs.getString("inquiry_date"));
				inquiry.setContent(rs.getString("content"));
				inquiry.setStatus(rs.getString("status"));

				list.add(inquiry);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}
		return list;
	}

	// お問い合わせ全件取得（ステータス降順、日時降順）
	public ArrayList<Inquiry> selectAll(String status) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Inquiry> list = new ArrayList<Inquiry>();

		try {

			String sql = "SELECT * FROM inquiry_info ORDER BY status desc, inquiry_date desc;";

			con = InquiryDAO.getConnection();
			smt = con.createStatement();
			System.out.println(sql);
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Inquiry inquiry = new Inquiry();
				inquiry.setInquiryId(rs.getString("inquiry_id"));
				inquiry.setUserName(rs.getString("user_name"));
				inquiry.setItem(rs.getString("item"));
				inquiry.setInquiryDate(rs.getString("inquiry_date"));
				inquiry.setContent(rs.getString("content"));
				inquiry.setStatus(rs.getString("status"));

				list.add(inquiry);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}
		return list;
	}

	// お問い合わせの検索（日時降順）
	public ArrayList<Inquiry> search(String userName, String item) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Inquiry> list = new ArrayList<Inquiry>();
		try {

			String sql = "SELECT * FROM inquiry_info WHERE user_name LIKE '%" + userName + "%' " + "AND item = '" + item + "';"
			+ " ORDER BY inquiry_date desc";

			con = InquiryDAO.getConnection();
			smt = con.createStatement();
			System.out.println(sql);
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Inquiry inquiry = new Inquiry();
				inquiry.setInquiryId(rs.getString("inquiry_id"));
				inquiry.setUserName(rs.getString("user_name"));
				inquiry.setItem(rs.getString("item"));
				inquiry.setInquiryDate(rs.getString("inquiry_date"));
				inquiry.setContent(rs.getString("content"));
				inquiry.setStatus(rs.getString("status"));

				list.add(inquiry);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}
		return list;
	}

	// お問い合わせの検索（日時昇順）
	public ArrayList<Inquiry> search(String userName, String item, String status) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Inquiry> list = new ArrayList<Inquiry>();
		try {

			/*  6/10差し替え
			 * ORDER BYの後の部分を status に変更
			*/
			String sql = "SELECT inquiry_id, user_name, item, inquiry_date, content, status "
			+ "FROM inquiry_info WHERE user_name LIKE '%" + userName + "%' " + "AND item = '" + item + "' "
			+ " ORDER BY status desc, inquiry_date desc;";

			con = InquiryDAO.getConnection();
			smt = con.createStatement();
			System.out.println(sql);
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Inquiry inquiry = new Inquiry();
				inquiry.setInquiryId(rs.getString("inquiry_id"));
				inquiry.setUserName(rs.getString("user_name"));
				inquiry.setItem(rs.getString("item"));
				inquiry.setInquiryDate(rs.getString("inquiry_date"));
				inquiry.setContent(rs.getString("content"));
				inquiry.setStatus(rs.getString("status"));

				list.add(inquiry);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}
		return list;
	}

	// お問い合わせの検索（日時降順、名前検索）
	public ArrayList<Inquiry> search(String userName) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Inquiry> list = new ArrayList<Inquiry>();
		try {

			String sql = "SELECT * FROM inquiry_info WHERE user_name LIKE '%" + userName + "%' ORDER BY inquiry_date desc;";

			con = InquiryDAO.getConnection();
			smt = con.createStatement();
			System.out.println(sql);
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Inquiry inquiry = new Inquiry();
				inquiry.setInquiryId(rs.getString("inquiry_id"));
				inquiry.setUserName(rs.getString("user_name"));
				inquiry.setItem(rs.getString("item"));
				inquiry.setInquiryDate(rs.getString("inquiry_date"));
				inquiry.setContent(rs.getString("content"));
				inquiry.setStatus(rs.getString("status"));

				list.add(inquiry);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}
		return list;
	}

	// お問い合わせ詳細の取得
	public Inquiry selectById(String inquiryId) {

		Connection con = null;
		Statement smt = null;

		Inquiry inquiry = new Inquiry();

		try {

			String sql = "SELECT * FROM inquiry_info WHERE inquiry_id = '" + inquiryId + "';";
			con = InquiryDAO.getConnection();
			smt = con.createStatement();
			System.out.println(sql);
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				inquiry.setInquiryId(rs.getString("inquiry_id"));
				inquiry.setUserName(rs.getString("user_name"));
				inquiry.setAddress(rs.getString("address"));
				inquiry.setUserEmail(rs.getString("user_email"));
				inquiry.setAge(rs.getString("age"));
				inquiry.setGender(rs.getString("gender"));
				inquiry.setStatus(rs.getString("status"));
				inquiry.setInquiryDate(rs.getString("inquiry_date"));
				inquiry.setSupportDate(rs.getString("support_date"));
				inquiry.setItem(rs.getString("item"));
				inquiry.setContent(rs.getString("content"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}
		return inquiry;
	}

	// お問い合わせの追加 6/9差し替え済み
	public void insert(Inquiry inquiry) {

		Connection con = null;
		Statement smt = null;

		try {

			String sql = "INSERT INTO inquiry_info(user_name, user_email, age, gender, address, item, content, inquiry_date, status) "
			+ "VALUES('" + inquiry.getUserName() + "','" + inquiry.getUserEmail() +"','" + inquiry.getAge() +"','" + inquiry.getGender() + "','" + inquiry.getAddress() + "','" + inquiry.getItem() + "','" + inquiry.getContent() + "',NOW(),'2');";

			con = InquiryDAO.getConnection();
			smt = con.createStatement();
			System.out.println(sql);
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}

	}

	// お問い合わせの更新
	public void update(String inquiryId, String adminId) {

		Connection con = null;
		Statement smt = null;

		try {

			// 返信状態、返信日時を変更する
			String sql = "UPDATE inquiry_info SET status = 1,support_date = NOW()"
			+ " WHERE inquiry_id = '" + inquiryId + "';";

			con = InquiryDAO.getConnection();
			smt = con.createStatement();

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {}
			}
		}
	}
}
