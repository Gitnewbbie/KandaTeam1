package servlet.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.Admin;
import dao.AdminDAO;

public class LoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// ダイレクトアクセスの場合、ログイン画面へ遷移
		request.getRequestDispatcher("/view/admin/login.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// オブジェクト宣言
		Admin admin = new Admin();
		AdminDAO adminDao = new AdminDAO();
		HttpSession session = request.getSession();

		// 変数
		String name = null;
		String password = null;
		String error = "";
		String message = ""; // ログイン画面のメッセージ

		try {
			// フォームからデータ取得
			request.setCharacterEncoding("UTF-8");
			name = request.getParameter("name");
			password = request.getParameter("password");

			// ユーザーの情報を取得
			admin = adminDao.selectByUser(name, password);

			// ユーザー名とパスワードが一致している場合処理を行う
			if (admin.getAdminId() != null) {
				// クッキーを保存
				Cookie idCookie = new Cookie("adminId", admin.getAdminId());
				idCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(idCookie);

				Cookie nameCookie = new Cookie("name", admin.getAdminName());
				nameCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(nameCookie);

				Cookie passCookie = new Cookie("password", admin.getPassword());
				passCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(passCookie);

				Cookie emailCookie = new Cookie("email", admin.getEmail());
				emailCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(emailCookie);

			} else {

				message = "入力データが間違っています。";//inquiryform10j
				return;
			}

		} catch (Exception e) {

			error = "エラー";
		} finally {

			if (error.equals("")) {
				if (message.equals("")) {

					// メニュー画面にフォワード
					session.setAttribute("admin", admin);
					request.getRequestDispatcher("/list").forward(request, response);
				} else {

					// ログイン画面にフォワード
					request.setAttribute("message", message);
					request.getRequestDispatcher("/view/admin/login.jsp").forward(request, response);
				}
			} else {

				// エラー画面へフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", "admin");
				request.getRequestDispatcher("/view/common/error.jsp").forward(request, response);
			}
		}
	}
}
