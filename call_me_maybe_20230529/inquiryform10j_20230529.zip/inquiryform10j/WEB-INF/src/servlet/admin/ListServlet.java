package servlet.admin;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.*;
import dao.InquiryDAO;

public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// オブジェクト宣言
		InquiryDAO inquiryDao = new InquiryDAO();
		ArrayList<Inquiry> list = new ArrayList<Inquiry>();

		//エラーメッセージ
		String error = "";

		try {

			// セッションの取得
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの場合
			if (admin == null) {
				error = "セッション切れの為、一覧表示は行なえませんでした。";
				return;
			}

			// 一覧取得
			list = inquiryDao.selectAll();
		} catch (Exception e) {

			error = "エラーです。";
		} finally {

			if (error.equals("")) {

				// リストにフォワード
				request.setAttribute("inquiry_list", list);
				request.getRequestDispatcher("/view/admin/list.jsp").forward(request, response);
			} else {

				//エラーへフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", "admin");
				request.getRequestDispatcher("/view/common/error.jsp").forward(request, response);
			}
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		this.doGet(request, response);
	}
}