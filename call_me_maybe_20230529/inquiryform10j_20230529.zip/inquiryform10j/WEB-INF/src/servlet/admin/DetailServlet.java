package servlet.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.*;
import dao.*;

public class DetailServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// オブジェクト宣言
		InquiryDAO inquiryDao = new InquiryDAO();
		Inquiry inquiry = new Inquiry();

		// 変数
		String id = null;
		String error = "";

		//管理者情報は紐づけしないため不要
		//String admin_name = "未対応"; //管理者名

		try {

			// セッションの取得
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの場合
			if (admin == null) {
				error = "セッション切れの為、一覧表示は行なえませんでした。";
				return;
			}


			// フォームからデータ取得
			request.setCharacterEncoding("UTF-8");
			id = request.getParameter("inquiry_id");

			// 検索メソッドを呼び出し

			inquiry = inquiryDao.selectById(id);
			//管理者情報は紐づけしないため不要
			/*
			if (inquiry.getAdminId() != null) {
				admin_name = adminDao.selectByadminname(Integer.parseInt(inquiry.getAdminId())); // 管理者名を取得
			}

			*/
			// リクエストスコープに登録
			request.setAttribute("inquiry", inquiry);
			//管理者情報は紐づけしないため不要
		//	request.setAttribute("admin_name", admin_name);

		} catch (Exception e) {

		} finally {
			if (error.equals("")) {

				// detail.jspへフォワード
				request.getRequestDispatcher("/view/admin/detail.jsp").forward(request, response);

			} else {

				// エラーへフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", "admin");
				request.getRequestDispatcher("/view/common/error.jsp").forward(request, response);
			}
		}
	}
}
