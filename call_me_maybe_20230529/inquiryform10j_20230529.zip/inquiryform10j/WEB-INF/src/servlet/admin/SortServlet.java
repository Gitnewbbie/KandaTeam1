package servlet.admin;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.*;
import dao.InquiryDAO;

public class SortServlet extends HttpServlet {
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		InquiryDAO inquiryDao = new InquiryDAO();	//DAOクラスのオブジェクト化

		request.setCharacterEncoding("UTF-8");		//文字エンコーディングの指定

		String status = request.getParameter("status");		//返信ステータスどっちかにソートするというボタンを押す？

		/*
		 * 6/10追加
		 * list.jspから item と name をリクエストスコープで受け取る
		 */
		String item = request.getParameter("item");		//検索されているときitemをもとにソート
		String name = request.getParameter("name");		//検索されているときnameをもとにソート

		ArrayList<Inquiry> list = new ArrayList<Inquiry>();	//ArrayListのオブジェクト化

		String error = ""; // エラー文を格納する変数

		try {

			// セッションの取得
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの場合
			if (admin == null) {
				error = "セッション切れの為、一覧表示は行なえませんでした。";
				return;
			}

			/*
			 *  6/10追加
			 *
			 */
			//検索した後のソートか一覧からソートしたのかをitemとnameの値から判断
			if (item.equals("")&& name.equals("")) {
				list = inquiryDao.selectAll(status);
			}else {
				list = inquiryDao.search(name,item,status);
			}

		}catch(Exception e) {

			error = "エラーです。";
		}finally {

			if (error.equals("")) {

				// リストにフォワード
				request.setAttribute("inquiry_list", list);
				request.getRequestDispatcher("/view/admin/list.jsp").forward(request, response);
			} else {

				//エラーへフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", "admin");
				request.getRequestDispatcher("/view/common/error.jsp").forward(request, response);
			}
		}
	}
}
