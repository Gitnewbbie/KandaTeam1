package servlet.user;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import bean.Inquiry;
import dao.InquiryDAO;
import util.SendMail;

public class CheckUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8"); // 文字エンコーディングの指定

		InquiryDAO inquiryDao = new InquiryDAO(); // 処理オブジェクトの作成
		Inquiry inquiry = new Inquiry(); // お問い合わせオブジェクト生成

		String error = "";

		// 各パラメータの取得
		String userName = request.getParameter("user_name"); // お名前
		String userEmail = request.getParameter("user_email"); // メールアドレス
		String age = request.getParameter("age"); // 年齢
		String gender = request.getParameter("gender");// 性別
		String address = request.getParameter("address"); // 住所
		String item = request.getParameter("item"); // 項目
		String content = request.getParameter("content"); // お問い合わせ内容

		// 空文字であればnullに変換
		if (age.equals("")) {
			age = null;
		}

		if (address.equals("")) {
			address = null;
		}

		// 登録に必要な各パラメータの格納
		inquiry.setUserName(userName);
		inquiry.setUserEmail(userEmail);
		inquiry.setAge(age);
		inquiry.setGender(gender);
		inquiry.setAddress(address);
		inquiry.setItem(item);
		inquiry.setContent(content);

		try {
			inquiryDao.insert(inquiry); // 登録処理

			/*
			 * SendMail sendMailObj = new SendMail(); // メール処理オブジェクトの作成
			 *
			 * String subject = "お問い合わせありがとうございます"; String text = inquiry.getUserName() +
			 * "様\n\n" + "この度はお問い合わせいただき、誠にありがとうございます。\n" +
			 * "3、4営業日以内にお返事いたしますので、しばらくお待ちください。\n\n" + "神田英会話スクール";
			 * sendMailObj.setFromInfo("asydaustin@gmail.com", "書籍管理システム"); //送信先のメールアドレスの指定
			 * sendMailObj.setRecipients(inquiry.getUserEmail()); //メールの件名の指定
			 * sendMailObj.setSubject(subject); //メールの本文の指定 sendMailObj.setText(text);
			 * sendMailObj.forwardMail();//送信にかかわる設定のメソッド
			 */

			// ユーザーへメール送信
			SendMail objMailUser = new SendMail();
			String path = getServletContext().getRealPath("templete\\inquiry_reception_user.txt");
			File file = new File(path);
			if (!file.exists()) {
				error = "メールが送信できませんでした。";
				return;
			}
			byte[] bytes = Files.readAllBytes(Paths.get(path));
			String text = new String(bytes, StandardCharsets.UTF_8); // メール送信情報設定
			objMailUser.setFromInfo("test.sender@kanda-it-school-system.com", "お問い合わせ管理システム"); // 送信先のメールアドレスの指定
			objMailUser.setRecipients(inquiry.getUserEmail()); // メールの件名の指定
			objMailUser.setSubject("【神田英会話スクール】お問い合わせを受け付けました"); // メールの本文の指定
			objMailUser.setText(setMailContent(inquiry, text));
			boolean judge = objMailUser.forwardMail();
			if (!judge) {
				error = "メールが送信できませんでした。";
				return;
			}

			// 管理者へメール送信
			SendMail objMailAdmin = new SendMail();
			path = getServletContext().getRealPath("templete\\inquiry_reception_admin.txt");
			file = new File(path);
			if (!file.exists()) {
				error = "メールが送信できませんでした。";
				return;
			}
			bytes = Files.readAllBytes(Paths.get(path));
			text = new String(bytes, StandardCharsets.UTF_8); // メール送信情報設定
			objMailAdmin.setFromInfo("test.sender@kanda-it-school-system.com", "お問い合わせ管理システム"); // 送信先のメールアドレスの指定
			objMailAdmin.setRecipients("system.project.team03@kanda-it-school-system.com"); // メールの件名の指定
			objMailAdmin.setSubject("【お問い合わせ管理システム】お問い合わせがありました"); // メールの本文の指定
			objMailAdmin.setText(setMailContent(inquiry, text));
			boolean judgeAdmin = objMailAdmin.forwardMail();
			if (!judgeAdmin) {
				error = "メールが送信できませんでした。";
				return;
			}

		} catch (Exception e) { // DBエラー有り
			error = "DBエラーが発生しました。";
			request.getRequestDispatcher("/view/common/error.jsp").forward(request, response); // フォワード処理

		} finally { // エラー無し
			if (error.equals("")) {
				request.getRequestDispatcher("/view/user/complete.jsp").forward(request, response); // フォワード処理
			}
		}
	}

	/**
	 * メール本文動的項目設定
	 *
	 * @param inquiry
	 * @param content
	 * @return
	 */
	private String setMailContent(Inquiry inquiry, String content) {
		// 名前
		content = content.replace("%name%", inquiry.getUserName());
		// 性別
		String dispGender = "";
		if (inquiry.getGender().equals("m")) {
			dispGender = "男性";
		} else {
			dispGender = "女性";
		}
		content = content.replace("%gender%", dispGender);
		// 住所
		content = content.replace("%address%", inquiry.getAddress());
		// メールアドレス
		content = content.replace("%mail%", inquiry.getUserEmail());
		// お問い合わせ項目
		int itemNum = Integer.parseInt(inquiry.getItem());
		String outputItem = ""; // 出力文字列
		switch (itemNum) {
		case 1:
			outputItem = "1.料金・お支払いについて";
			break;
		case 2:
			outputItem = "2.講座、コース、教材について";
			break;
		case 3:
			outputItem = "3.学習の進め方について";
			break;
		case 4:
			outputItem = "4.受講期限について";
			break;
		case 5:
			outputItem = "5.受講終了後のサポートについて";
			break;
		default:
			outputItem = "6.その他";
		}
		content = content.replace("%item%", outputItem);
		// お問い合わせ内容
		content = content.replace("%content%", inquiry.getContent());
		return content;
	}

}
