package bean;

public class Inquiry {

	private String inquiryId;
	private String userName;
	private String address;
	private String userEmail;
	private String item;
	private String content;
	private String status;
	private String adminId;
	private String inquiryDate;
	private String supportDate;
	private String age;
	private String gender;

	// コンストラクタ
	public Inquiry() {
		this.inquiryId = null;
		this.userName = null;
		this.address = null;
		this.userEmail = null;
		this.item = null;
		this.content = null;
		this.status = null;
		this.adminId = null;
		this.inquiryDate = null;
		this.supportDate = null;
		this.age = null;
		this.gender = null;
	}

	public void setInquiryId(String inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getInquiryId() {
		return this.inquiryId;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserEmail() {
		return this.userEmail;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItem() {
		return this.item;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getContent() {
		return this.content;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return this.status;
	}

	public void setAdminId(String addminId) {
		this.adminId = addminId;
	}

	public String getAdminId() {
		return this.adminId;
	}

	public void setInquiryDate(String inquiryDate) {
		this.inquiryDate = inquiryDate;
	}

	public String getInquiryDate() {
		return this.inquiryDate;
	}

	public void setSupportDate(String supportDate) {
		this.supportDate = supportDate;
	}

	public String getSupportDate() {
		return this.supportDate;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getAge() {
		if (this.age == null || this.age.equals("")) {
			return "nul";
		} else {
			return this.age;
		}

	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGender() {
		if (this.gender == null || this.gender.equals("")) {
			return "n";
		} else {
			return this.gender;
		}
	}
}
